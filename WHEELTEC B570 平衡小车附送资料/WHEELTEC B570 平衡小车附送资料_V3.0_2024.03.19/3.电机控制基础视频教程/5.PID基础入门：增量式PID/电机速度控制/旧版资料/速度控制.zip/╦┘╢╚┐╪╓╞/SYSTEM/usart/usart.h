#ifndef __USART_H
#define __USART_H
 /**************************************************************************
���ߣ�ƽ��С��֮�� 
�Ա����̣�http://shop114407458.taobao.com/
**************************************************************************/
#include "sys.h"
#include "stdio.h"	 
void usart1_send(u8 data);
void uart_init(u32 bound);
#endif	   
















