/*
 * ReadDistance.c
 *
 *  Created on: Jun 14, 2022
 *      Author: lf
 */
#include "ReadDistance.h"
#include "tim.h"
//����һ��16λ��TIM2CH2_CAPTURE_STA���������ڴ�Ų���״̬
//����һ��16λ��TIM2CH2_CAPTURE_VAL���������ڴ�Ų������ֵ
u16 TIM2CH2_CAPTURE_STA,TIM2CH2_CAPTURE_VAL;

//定义一个16位的TIM2CH2_CAPTURE_STA变量：用于存放捕获状态
//定义一个16位的TIM2CH2_CAPTURE_VAL变量：用于存放捕获的数值
u16 TIM2CH2_CAPTURE_STA,TIM2CH2_CAPTURE_VAL;

/**************************************************************************
Function: Ultrasonic receiving echo function
Input   : none
Output  : none
函数功能：超声波接收回波函数
入口参数: 无
返回  值：无
**************************************************************************/
void Read_Distane(void)
{
	 PAout(3)=1;
	 delay_us(15);
	 PAout(3)=0;
	 if(TIM2CH2_CAPTURE_STA&0X80)//成功捕获到了一次高电平
	 {
		 Distance=TIM2CH2_CAPTURE_STA&0X3F;
		 Distance*=65536;					        //溢出时间总和
		 Distance+=TIM2CH2_CAPTURE_VAL;		//得到总的高电平时间
		 Distance=Distance*170/1000;      //时间*声速/2（来回） 一个计数0.001ms
		 TIM2CH2_CAPTURE_STA=0;			//开启下一次捕获
	 }
}


///**************************************************************************
//Function: Pulse width reading interruption of ultrasonic echo
//Input   : none
//Output  : none
//函数功能：超声波回波脉宽读取中断①：捕获中断
//入口参数: 无
//返回  值：无
//**************************************************************************/
//进入定时器2中断后，在定时器2中断里判断出是捕获中断，然后进入此回调函数
void HAL_TIM_IC_CaptureCallback(TIM_HandleTypeDef *htim)//捕获中断发生时执行
{
	if(htim==&htim2)
	{
		 if((TIM2CH2_CAPTURE_STA&0X80)==0)//还未成功捕获
		 {
				if(TIM2CH2_CAPTURE_STA&0X40)  //捕获到一个下降沿
				{
				 TIM2CH2_CAPTURE_STA|=0X80;  //标记成功捕获到一次高电平脉宽
				 TIM2CH2_CAPTURE_VAL=HAL_TIM_ReadCapturedValue(&htim2,TIM_CHANNEL_2);//获取当前的捕获值.
				 __HAL_TIM_DISABLE(&htim2);
				 TIM_RESET_CAPTUREPOLARITY(&htim2,TIM_CHANNEL_2);   //一定要先清除原来的设置！！
				 TIM_SET_CAPTUREPOLARITY(&htim2,TIM_CHANNEL_2,TIM_ICPOLARITY_RISING);//配置TIM2通道2上升沿捕获
				 __HAL_TIM_ENABLE(&htim2);//使能定时器2
				}
				else          //还未开始,第一次捕获上升沿
				{
				 TIM2CH2_CAPTURE_STA=0;   //清空
				 TIM2CH2_CAPTURE_VAL=0;
				 TIM2CH2_CAPTURE_STA|=0X40;  //标记捕获到了上升沿
				 //配置tim前一定要先关闭tim，配置完以后再使能
				 __HAL_TIM_DISABLE(&htim2);        //关闭定时器2
				 __HAL_TIM_SET_COUNTER(&htim2,0);  //计数器CNT置0
				 TIM_RESET_CAPTUREPOLARITY(&htim2,TIM_CHANNEL_2);   //一定要先清除原来的设置！！
				 TIM_SET_CAPTUREPOLARITY(&htim2,TIM_CHANNEL_2,TIM_ICPOLARITY_FALLING);//定时器3通道3设置为下降沿捕获
				 __HAL_TIM_ENABLE(&htim2);//使能定时器2
				}
		 }
	}
}

/**************************************************************************
Function: Pulse width reading interruption of ultrasonic echo
Input   : none
Output  : none
函数功能：超声波回波脉宽读取中断②：更新中断
入口参数: 无
返回  值：无
**************************************************************************/
//定时器更新中断（计数溢出）中断处理回调函数， 该函数在HAL_TIM_IRQHandler中会被调用
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)//更新中断（溢出）发生时执行
{
	if(htim==&htim2)
	{
		 if((TIM2CH2_CAPTURE_STA&0X80)==0)//还未成功捕获
		 {
			if(TIM2CH2_CAPTURE_STA&0X40)//已经捕获到高电平了
			{
			 if((TIM2CH2_CAPTURE_STA&0X3F)==0X3F)//高电平太长了
			 {
				TIM2CH2_CAPTURE_STA|=0X80;  //标记成功捕获了一次
				TIM2CH2_CAPTURE_VAL=0XFFFF;
			 }
			 else
				TIM2CH2_CAPTURE_STA++;
			}
		 }
	}

}
