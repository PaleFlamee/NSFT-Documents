#ifndef __EXTI_H 
#define __EXTI_H 
#include "stm32f10x_exti.h" 

void EXTI5_Init(void); 

#endif 
