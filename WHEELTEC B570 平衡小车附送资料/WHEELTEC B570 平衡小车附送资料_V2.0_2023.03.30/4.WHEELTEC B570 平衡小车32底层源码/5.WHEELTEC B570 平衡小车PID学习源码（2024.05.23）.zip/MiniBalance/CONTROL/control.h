#ifndef __CONTROL_H
#define __CONTROL_H
#include "sys.h"
  /**************************************************************************
���ߣ�ƽ��С��֮��
�ҵ��Ա�С�꣺http://shop114407458.taobao.com/
**************************************************************************/
#define PI 3.14159265
int EXTI15_10_IRQHandler(void);
void Set_Pwm(int motor_left,int motor_right);
void Key(void);
int PWM_Limit(int IN,int max,int min);
u8 Turn_Off(int voltage);
int myabs(int a);
int Incremental_PI (int Encoder,int Target);
int Position_PID (int Position,int Target);
void PID_Adjust(int encoder);
#endif
