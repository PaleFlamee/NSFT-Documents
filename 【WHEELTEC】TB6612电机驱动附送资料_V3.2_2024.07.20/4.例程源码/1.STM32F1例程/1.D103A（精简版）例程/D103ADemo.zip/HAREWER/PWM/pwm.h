#ifndef __PWM_H
#define	__PWM_H

#include "stm32f10x.h"

void	pwm_int(void);
void Set_PWMA(int PWM);
void Set_PWMB(int PWM);


#endif

